# Scholarship-Information-System
# With the help of this project, it connects students with financial aid opportunities.
